"use client";
import { useEffect, useRef } from "react";

export default function Hero() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles: {
      x: number;
      y: number;
      vx: number;
      vy: number;
      size: number;
      alpha: number;
    }[] = [];

    for (let i = 0; i < 60; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
        size: Math.random() * 1.5 + 0.5,
        alpha: Math.random() * 0.4 + 0.1,
      });
    }

    let animId: number;
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0) p.x = canvas.width;
        if (p.x > canvas.width) p.x = 0;
        if (p.y < 0) p.y = canvas.height;
        if (p.y > canvas.height) p.y = 0;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(0, 229, 255, ${p.alpha})`;
        ctx.fill();
      });

      // Draw lines between nearby particles
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 120) {
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.strokeStyle = `rgba(0, 229, 255, ${0.06 * (1 - dist / 120)})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      }

      animId = requestAnimationFrame(animate);
    };
    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    window.addEventListener("resize", handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden grid-bg">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
        style={{ opacity: 0.6 }}
      />

      {/* Radial glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 60% 50% at 50% 50%, rgba(0,229,255,0.04) 0%, transparent 70%)",
        }}
      />

      {/* Left accent line */}
      <div className="absolute left-6 top-32 bottom-32 w-px bg-gradient-to-b from-transparent via-[#1a2540] to-transparent hidden md:block" />

      <div className="relative z-10 max-w-6xl mx-auto px-6 py-32">
        <div className="max-w-3xl">
          {/* Status badge */}
          <div className="animate-fade-up opacity-0 delay-100 inline-flex items-center gap-2 mb-8">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-mono text-xs text-[#718096] tracking-widest uppercase">
              Available for Opportunities
            </span>
          </div>

          {/* Main heading */}
          <h1 className="font-display font-bold leading-none mb-6 animate-fade-up opacity-0 delay-200">
            <span className="block text-5xl md:text-7xl lg:text-8xl text-[#e2e8f0]">
              Manila
            </span>
            <span className="block text-5xl md:text-7xl lg:text-8xl text-glow text-[#00e5ff]">
              Cherku
            </span>
          </h1>

          {/* Tagline */}
          <div className="flex items-center gap-3 mb-4 animate-fade-up opacity-0 delay-300">
            <div className="w-8 h-px bg-[#00e5ff]" />
            <p className="font-mono text-sm text-[#00e5ff] tracking-wider uppercase">
              Full Stack Engineer · MERN · ML
            </p>
          </div>

          {/* Description */}
          <p className="text-lg md:text-xl text-[#718096] leading-relaxed mb-10 max-w-xl animate-fade-up opacity-0 delay-400 font-body">
            I architect end-to-end web systems that scale — from RESTful APIs
            handling thousands of requests to React interfaces users actually
            enjoy. Currently studying CS with a focus on intelligent systems.
          </p>

          {/* CTAs */}
          <div className="flex flex-wrap gap-4 animate-fade-up opacity-0 delay-500">
            <a
              href="#projects"
              className="group relative inline-flex items-center gap-2 px-6 py-3 bg-[#00e5ff] text-[#080c14] font-mono text-sm font-medium tracking-wider uppercase overflow-hidden transition-all duration-300 hover:shadow-[0_0_30px_rgba(0,229,255,0.4)]"
            >
              <span className="relative z-10">View My Work</span>
              <svg className="w-4 h-4 relative z-10 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </a>
            <a
              href="https://github.com/ManilaCherku"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 border border-[#1a2540] text-[#718096] font-mono text-sm tracking-wider uppercase hover:border-[#00e5ff] hover:text-[#00e5ff] transition-all duration-300"
            >
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z" />
              </svg>
              GitHub
            </a>
            <a
              href="https://linkedin.com/in/manilacherku"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 border border-[#1a2540] text-[#718096] font-mono text-sm tracking-wider uppercase hover:border-[#7c3aed] hover:text-[#7c3aed] transition-all duration-300"
            >
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
              </svg>
              LinkedIn
            </a>
          </div>

          {/* Scroll indicator */}
          <div className="mt-20 hidden md:flex items-center gap-3 animate-fade-in opacity-0 delay-800">
            <div className="w-5 h-8 border border-[#1a2540] rounded-full flex items-start justify-center pt-1.5">
              <div className="w-0.5 h-2 bg-[#00e5ff] rounded-full animate-bounce" />
            </div>
            <span className="font-mono text-xs text-[#4a5568] tracking-widest">SCROLL</span>
          </div>
        </div>

        {/* Floating stat cards */}
        <div className="absolute right-6 top-1/2 -translate-y-1/2 hidden xl:flex flex-col gap-4 animate-fade-up opacity-0 delay-700">
          {[
            { value: "150+", label: "Problems Solved" },
            { value: "2+", label: "MERN Apps Built" },
            { value: "90%", label: "ML Model Accuracy" },
          ].map((stat) => (
            <div
              key={stat.label}
              className="group w-36 p-4 border border-[#1a2540] bg-[rgba(13,20,36,0.6)] backdrop-blur hover:border-[#00e5ff] transition-all duration-300 hover:glow-accent cursor-default"
            >
              <div className="font-display text-2xl font-bold text-[#00e5ff] group-hover:text-glow">
                {stat.value}
              </div>
              <div className="font-mono text-[10px] text-[#4a5568] uppercase tracking-wider mt-1">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
