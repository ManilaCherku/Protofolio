"use client";

const timeline = [
  {
    year: "2027",
    title: "B.Tech / B.Sc — CSE (Data Science)",
    org: "Vignan Institute of Technology",
    detail: "Expected Graduation · Hyderabad, India",
  },
  {
    year: "2023",
    title: "Intermediate (MPC)",
    org: "Sri Gayatri Junior College",
    detail: "95.8% · Top performer",
  },
  {
    year: "2021",
    title: "Secondary School Certificate",
    org: "New Chaitanya High School",
    detail: "96% · Strong academic record",
  },
];

const certs = [
  "Web Development · Skill Vertex",
  "Google Cloud Computing Foundations · NPTEL",
  "Data Structures in C · Great Learning",
  "Cyber Security · NPTEL",
  "Data Analytics · NPTEL",
];

export default function About() {
  return (
    <section id="about" className="py-28 relative overflow-hidden">
      {/* Section accent */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#1a2540] to-transparent" />

      <div className="max-w-6xl mx-auto px-6">
        {/* Section header */}
        <div className="flex items-center gap-4 mb-16">
          <span className="font-mono text-xs text-[#00e5ff] tracking-widest uppercase">
            01
          </span>
          <div className="w-12 h-px bg-[#00e5ff]" />
          <h2 className="font-display text-3xl md:text-4xl font-bold text-[#e2e8f0]">
            About
          </h2>
        </div>

        <div className="grid md:grid-cols-2 gap-16 items-start">
          {/* Left: Bio */}
          <div>
            <div className="relative mb-10">
              <div className="absolute -left-4 top-0 bottom-0 w-px bg-gradient-to-b from-[#00e5ff] via-[#7c3aed] to-transparent" />
              <p className="text-[#a0aec0] leading-relaxed text-lg font-body mb-6">
                I&apos;m a computer science student with a sharp focus on full-stack
                engineering and intelligent systems. I don&apos;t just write
                code — I build systems that are architecturally sound, fast,
                and maintainable.
              </p>
              <p className="text-[#718096] leading-relaxed font-body">
                My work spans RESTful API design, React performance
                optimization, and deploying machine learning models into
                production pipelines. I&apos;m drawn to problems that sit at the
                intersection of engineering rigor and real-world impact.
              </p>
            </div>

            {/* Quick facts */}
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: "Location", value: "Hyderabad, India" },
                { label: "Focus", value: "Full Stack + ML" },
                { label: "Stack", value: "MERN + Python" },
                { label: "Status", value: "Open to Work" },
              ].map((fact) => (
                <div
                  key={fact.label}
                  className="group p-4 border border-[#1a2540] hover:border-[#00e5ff]/40 transition-all duration-300 cursor-default"
                >
                  <div className="font-mono text-[10px] text-[#4a5568] uppercase tracking-wider mb-1">
                    {fact.label}
                  </div>
                  <div className="font-display text-sm font-medium text-[#e2e8f0] group-hover:text-[#00e5ff] transition-colors">
                    {fact.value}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Education + Certs */}
          <div>
            <h3 className="font-mono text-xs text-[#718096] uppercase tracking-widest mb-6">
              Education
            </h3>
            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-2.5 top-2 bottom-2 w-px bg-[#1a2540]" />
              <div className="space-y-6">
                {timeline.map((item) => (
                  <div key={item.year} className="group flex gap-5 pl-0">
                    <div className="relative flex-shrink-0 mt-1">
                      <div className="w-5 h-5 border border-[#1a2540] bg-[#080c14] group-hover:border-[#00e5ff] group-hover:bg-[#00e5ff]/10 transition-all duration-300 flex items-center justify-center">
                        <div className="w-1.5 h-1.5 bg-[#00e5ff] opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                    </div>
                    <div>
                      <div className="font-mono text-[10px] text-[#00e5ff] tracking-widest mb-0.5">
                        {item.year}
                      </div>
                      <div className="font-display text-sm font-semibold text-[#e2e8f0]">
                        {item.title}
                      </div>
                      <div className="font-body text-xs text-[#718096] mt-0.5">
                        {item.org}
                      </div>
                      <div className="font-mono text-[10px] text-[#4a5568] mt-0.5">
                        {item.detail}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Certifications */}
            <div className="mt-10">
              <h3 className="font-mono text-xs text-[#718096] uppercase tracking-widest mb-4">
                Certifications
              </h3>
              <div className="space-y-2">
                {certs.map((cert) => (
                  <div
                    key={cert}
                    className="flex items-center gap-3 group cursor-default"
                  >
                    <div className="w-1 h-1 bg-[#00e5ff] opacity-60 group-hover:opacity-100 flex-shrink-0" />
                    <span className="font-body text-xs text-[#718096] group-hover:text-[#a0aec0] transition-colors">
                      {cert}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
