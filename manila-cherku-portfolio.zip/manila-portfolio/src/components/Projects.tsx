"use client";

const projects = [
  {
    id: "01",
    title: "Skill Swap Platform",
    tagline: "Peer-to-peer skill exchange at scale",
    description:
      "A community-driven MERN stack application enabling users to barter skills — teaching what they know for what they want to learn. Designed a normalized MongoDB schema supporting complex user relationships and real-time interaction state.",
    highlights: [
      "JWT-secured RESTful APIs with role-based access control",
      "React context architecture reducing prop-drilling by 80%",
      "Optimized MongoDB aggregation pipelines for feed generation",
      "Responsive UI with component-level code splitting",
    ],
    stack: ["MongoDB", "Express", "React", "Node.js", "JWT", "REST API"],
    accent: "#00e5ff",
    github: "https://github.com/ManilaCherku",
    featured: true,
    metric: "Full-Stack",
  },
  {
    id: "02",
    title: "Intrusion Detection System",
    tagline: "Real-time network threat intelligence",
    description:
      "A Python-based network security system that classifies traffic patterns as benign or malicious in real time. Applied rigorous feature engineering on raw packet data to expose behavioral signals that standard tools miss.",
    highlights: [
      "90% classification accuracy across 5 attack categories",
      "Feature selection reduced model inference time by 35%",
      "Evaluated 4 supervised algorithms; tuned winning model with cross-validation",
      "Exportable threat reports with confidence scoring",
    ],
    stack: ["Python", "Scikit-learn", "Pandas", "NumPy", "Feature Engineering"],
    accent: "#7c3aed",
    github: "https://github.com/ManilaCherku",
    featured: true,
    metric: "90% Accuracy",
  },
];

export default function Projects() {
  return (
    <section id="projects" className="py-28 relative">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#1a2540] to-transparent" />

      {/* Background accent */}
      <div
        className="absolute right-0 top-1/4 w-64 h-64 pointer-events-none"
        style={{
          background:
            "radial-gradient(circle, rgba(124,58,237,0.06) 0%, transparent 70%)",
        }}
      />

      <div className="max-w-6xl mx-auto px-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-16">
          <div className="flex items-center gap-4">
            <span className="font-mono text-xs text-[#00e5ff] tracking-widest uppercase">
              02
            </span>
            <div className="w-12 h-px bg-[#00e5ff]" />
            <h2 className="font-display text-3xl md:text-4xl font-bold text-[#e2e8f0]">
              Featured Work
            </h2>
          </div>
          <a
            href="https://github.com/ManilaCherku"
            target="_blank"
            rel="noopener noreferrer"
            className="hidden md:flex items-center gap-2 font-mono text-xs text-[#718096] hover:text-[#00e5ff] transition-colors tracking-wider uppercase hover-underline"
          >
            All Projects
            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 17L17 7M17 7H7M17 7v10" />
            </svg>
          </a>
        </div>

        {/* Project cards */}
        <div className="space-y-8">
          {projects.map((project, idx) => (
            <div
              key={project.id}
              className="group relative border border-[#1a2540] hover:border-opacity-60 transition-all duration-500 overflow-hidden"
              style={{
                ["--accent-color" as string]: project.accent,
              }}
            >
              {/* Hover glow */}
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                style={{
                  background: `radial-gradient(ellipse at ${idx % 2 === 0 ? "left" : "right"} center, ${project.accent}06 0%, transparent 70%)`,
                }}
              />

              {/* Top border accent */}
              <div
                className="absolute top-0 left-0 right-0 h-px opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                style={{ background: project.accent }}
              />

              <div className="relative p-8 md:p-10">
                <div className="grid md:grid-cols-[1fr_auto] gap-8">
                  {/* Content */}
                  <div>
                    <div className="flex items-start gap-4 mb-4">
                      <span
                        className="font-mono text-xs opacity-40 mt-1 flex-shrink-0"
                        style={{ color: project.accent }}
                      >
                        {project.id}
                      </span>
                      <div>
                        <h3 className="font-display text-2xl md:text-3xl font-bold text-[#e2e8f0] mb-1 group-hover:text-white transition-colors">
                          {project.title}
                        </h3>
                        <p
                          className="font-mono text-xs tracking-wider uppercase"
                          style={{ color: project.accent, opacity: 0.8 }}
                        >
                          {project.tagline}
                        </p>
                      </div>
                    </div>

                    <p className="text-[#718096] leading-relaxed mb-6 font-body max-w-2xl">
                      {project.description}
                    </p>

                    <ul className="space-y-2 mb-8">
                      {project.highlights.map((h) => (
                        <li key={h} className="flex items-start gap-3">
                          <span
                            className="mt-1.5 w-1 h-1 flex-shrink-0"
                            style={{ background: project.accent }}
                          />
                          <span className="font-body text-sm text-[#a0aec0]">
                            {h}
                          </span>
                        </li>
                      ))}
                    </ul>

                    {/* Stack */}
                    <div className="flex flex-wrap gap-2">
                      {project.stack.map((tech) => (
                        <span
                          key={tech}
                          className="font-mono text-[10px] px-2 py-1 border tracking-wider uppercase transition-colors duration-200"
                          style={{
                            borderColor: `${project.accent}30`,
                            color: `${project.accent}80`,
                          }}
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Right: metric + links */}
                  <div className="flex md:flex-col items-start md:items-end justify-between gap-4">
                    <div className="text-right">
                      <div
                        className="font-display text-3xl md:text-4xl font-bold"
                        style={{ color: project.accent }}
                      >
                        {project.metric}
                      </div>
                      <div className="font-mono text-[10px] text-[#4a5568] uppercase tracking-wider">
                        Category
                      </div>
                    </div>

                    <div className="flex gap-3">
                      <a
                        href={project.github}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="group/btn inline-flex items-center gap-2 px-4 py-2 border font-mono text-xs tracking-wider uppercase transition-all duration-200"
                        style={{
                          borderColor: `${project.accent}40`,
                          color: `${project.accent}80`,
                        }}
                        onMouseEnter={(e) => {
                          const el = e.currentTarget as HTMLElement;
                          el.style.borderColor = project.accent;
                          el.style.color = project.accent;
                        }}
                        onMouseLeave={(e) => {
                          const el = e.currentTarget as HTMLElement;
                          el.style.borderColor = `${project.accent}40`;
                          el.style.color = `${project.accent}80`;
                        }}
                      >
                        <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z" />
                        </svg>
                        Code
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Workshops */}
        <div className="mt-16 p-8 border border-[#1a2540]">
          <h3 className="font-mono text-xs text-[#718096] uppercase tracking-widest mb-6">
            Technical Workshops & Training
          </h3>
          <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { title: "HTML & CSS", org: "TASK · Telangana" },
              { title: "Network Simulation (NS2)", org: "TASK · Telangana" },
              { title: "Database Management", org: "TASK · Telangana" },
              { title: "Machine Learning", org: "Innomatics Research Labs" },
            ].map((w) => (
              <div key={w.title} className="group p-4 border border-[#1a2540] hover:border-[#00e5ff]/30 transition-all duration-200 cursor-default">
                <div className="font-display text-sm font-semibold text-[#e2e8f0] mb-1 group-hover:text-[#00e5ff] transition-colors">
                  {w.title}
                </div>
                <div className="font-mono text-[10px] text-[#4a5568] uppercase tracking-wider">
                  {w.org}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
