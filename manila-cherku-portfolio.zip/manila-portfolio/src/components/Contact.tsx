"use client";
import { useState } from "react";

const contactLinks = [
  {
    label: "Email",
    value: "cherkumanila@gmail.com",
    href: "mailto:cherkumanila@gmail.com",
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
      </svg>
    ),
  },
  {
    label: "GitHub",
    value: "github.com/ManilaCherku",
    href: "https://github.com/ManilaCherku",
    icon: (
      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
        <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z" />
      </svg>
    ),
  },
  {
    label: "LinkedIn",
    value: "linkedin.com/in/manilacherku",
    href: "https://linkedin.com/in/manilacherku",
    icon: (
      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
        <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
      </svg>
    ),
  },
  {
    label: "Location",
    value: "Hyderabad, India",
    href: null,
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
      </svg>
    ),
  },
];

export default function Contact() {
  const [copied, setCopied] = useState(false);

  const copyEmail = () => {
    navigator.clipboard.writeText("cherkumanila@gmail.com");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section id="contact" className="py-28 relative">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#1a2540] to-transparent" />

      {/* Background glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 50% 60% at 50% 100%, rgba(0,229,255,0.03) 0%, transparent 70%)",
        }}
      />

      <div className="max-w-6xl mx-auto px-6">
        {/* Header */}
        <div className="flex items-center gap-4 mb-16">
          <span className="font-mono text-xs text-[#00e5ff] tracking-widest uppercase">
            04
          </span>
          <div className="w-12 h-px bg-[#00e5ff]" />
          <h2 className="font-display text-3xl md:text-4xl font-bold text-[#e2e8f0]">
            Contact
          </h2>
        </div>

        <div className="grid md:grid-cols-2 gap-16">
          {/* Left: CTA */}
          <div>
            <h3 className="font-display text-4xl md:text-5xl font-bold text-[#e2e8f0] leading-tight mb-6">
              Let&apos;s build
              <br />
              <span className="text-[#00e5ff] text-glow">something</span>
              <br />
              great.
            </h3>
            <p className="text-[#718096] leading-relaxed mb-8 font-body">
              I&apos;m actively seeking software engineering internships and
              entry-level roles. If you&apos;re looking for someone who can ship
              full-stack features, optimize APIs, and bring engineering
              discipline to a growing team — let&apos;s talk.
            </p>

            {/* Copy email button */}
            <button
              onClick={copyEmail}
              className="group inline-flex items-center gap-3 px-6 py-3 border border-[#1a2540] hover:border-[#00e5ff] transition-all duration-300"
            >
              <span className="font-mono text-sm text-[#718096] group-hover:text-[#00e5ff] transition-colors">
                {copied ? "Copied!" : "cherkumanila@gmail.com"}
              </span>
              <span className="text-[#4a5568] group-hover:text-[#00e5ff] transition-colors">
                {copied ? (
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                ) : (
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                )}
              </span>
            </button>
          </div>

          {/* Right: Links */}
          <div>
            <div className="space-y-3">
              {contactLinks.map((link) =>
                link.href ? (
                  <a
                    key={link.label}
                    href={link.href}
                    target={link.href.startsWith("http") ? "_blank" : undefined}
                    rel={link.href.startsWith("http") ? "noopener noreferrer" : undefined}
                    className="group flex items-center gap-4 p-5 border border-[#1a2540] hover:border-[#00e5ff]/40 transition-all duration-300 hover:bg-[rgba(0,229,255,0.02)]"
                  >
                    <div className="text-[#4a5568] group-hover:text-[#00e5ff] transition-colors flex-shrink-0">
                      {link.icon}
                    </div>
                    <div className="flex-1">
                      <div className="font-mono text-[10px] text-[#4a5568] uppercase tracking-widest mb-0.5">
                        {link.label}
                      </div>
                      <div className="font-body text-sm text-[#718096] group-hover:text-[#e2e8f0] transition-colors">
                        {link.value}
                      </div>
                    </div>
                    <svg className="w-4 h-4 text-[#4a5568] group-hover:text-[#00e5ff] transition-all duration-200 group-hover:translate-x-1 group-hover:-translate-y-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 17L17 7M17 7H7M17 7v10" />
                    </svg>
                  </a>
                ) : (
                  <div
                    key={link.label}
                    className="flex items-center gap-4 p-5 border border-[#1a2540]"
                  >
                    <div className="text-[#4a5568] flex-shrink-0">{link.icon}</div>
                    <div>
                      <div className="font-mono text-[10px] text-[#4a5568] uppercase tracking-widest mb-0.5">
                        {link.label}
                      </div>
                      <div className="font-body text-sm text-[#718096]">
                        {link.value}
                      </div>
                    </div>
                  </div>
                )
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-24 pt-8 border-t border-[#1a2540] flex flex-col sm:flex-row justify-between items-center gap-4">
          <span className="font-mono text-xs text-[#4a5568]">
            © 2024 Manila Cherku · Built with Next.js
          </span>
          <div className="flex items-center gap-2">
            <span className="font-mono text-xs text-[#4a5568]">
              Designed & developed with intent
            </span>
            <span className="text-[#00e5ff] text-xs">◈</span>
          </div>
        </div>
      </div>
    </section>
  );
}
