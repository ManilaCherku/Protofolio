"use client";

const skillGroups = [
  {
    category: "Frontend",
    icon: "◈",
    skills: [
      { name: "React", level: 85 },
      { name: "JavaScript", level: 82 },
      { name: "HTML & CSS", level: 90 },
    ],
  },
  {
    category: "Backend",
    icon: "◉",
    skills: [
      { name: "Node.js", level: 78 },
      { name: "Express", level: 75 },
      { name: "REST APIs", level: 82 },
    ],
  },
  {
    category: "Database",
    icon: "◎",
    skills: [
      { name: "MongoDB", level: 80 },
      { name: "SQL / DBMS", level: 75 },
    ],
  },
  {
    category: "ML & Data",
    icon: "◈",
    skills: [
      { name: "Python", level: 85 },
      { name: "Scikit-learn", level: 72 },
      { name: "Pandas / NumPy", level: 75 },
    ],
  },
];

const tags = [
  "Data Structures & Algorithms",
  "Operating Systems",
  "Computer Networks",
  "Problem Solving",
  "Feature Engineering",
  "Model Evaluation",
  "Git / Version Control",
  "Agile Collaboration",
  "Google Cloud",
  "Cyber Security",
  "Data Analytics",
  "System Design",
];

export default function Skills() {
  return (
    <section id="skills" className="py-28 relative">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#1a2540] to-transparent" />

      {/* Background */}
      <div
        className="absolute left-0 bottom-0 w-96 h-96 pointer-events-none"
        style={{
          background:
            "radial-gradient(circle, rgba(0,229,255,0.04) 0%, transparent 70%)",
        }}
      />

      <div className="max-w-6xl mx-auto px-6">
        {/* Header */}
        <div className="flex items-center gap-4 mb-16">
          <span className="font-mono text-xs text-[#00e5ff] tracking-widest uppercase">
            03
          </span>
          <div className="w-12 h-px bg-[#00e5ff]" />
          <h2 className="font-display text-3xl md:text-4xl font-bold text-[#e2e8f0]">
            Skills
          </h2>
        </div>

        {/* Skill bars */}
        <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-6 mb-12">
          {skillGroups.map((group) => (
            <div
              key={group.category}
              className="group p-6 border border-[#1a2540] hover:border-[#00e5ff]/30 transition-all duration-300"
            >
              <div className="flex items-center gap-2 mb-6">
                <span className="text-[#00e5ff] text-lg">{group.icon}</span>
                <span className="font-mono text-xs text-[#718096] uppercase tracking-widest">
                  {group.category}
                </span>
              </div>
              <div className="space-y-5">
                {group.skills.map((skill) => (
                  <div key={skill.name}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-display text-sm font-medium text-[#e2e8f0]">
                        {skill.name}
                      </span>
                      <span className="font-mono text-[10px] text-[#4a5568]">
                        {skill.level}%
                      </span>
                    </div>
                    <div className="w-full h-px bg-[#1a2540] relative overflow-hidden">
                      <div
                        className="absolute inset-y-0 left-0 h-full bg-gradient-to-r from-[#00e5ff] to-[#7c3aed] transition-all duration-1000 group-hover:shadow-[0_0_6px_rgba(0,229,255,0.6)]"
                        style={{ width: `${skill.level}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Tag cloud */}
        <div className="border border-[#1a2540] p-8">
          <div className="font-mono text-[10px] text-[#4a5568] uppercase tracking-widest mb-6">
            Additional Competencies
          </div>
          <div className="flex flex-wrap gap-3">
            {tags.map((tag) => (
              <span
                key={tag}
                className="group cursor-default font-mono text-[11px] px-3 py-1.5 border border-[#1a2540] text-[#718096] hover:border-[#00e5ff]/40 hover:text-[#e2e8f0] transition-all duration-200 tracking-wide"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* LeetCode achievement */}
        <div className="mt-6 p-6 border border-[#1a2540] bg-[#0d1424] flex flex-col sm:flex-row items-start sm:items-center gap-6 hover:border-[#00e5ff]/30 transition-all duration-300">
          <div className="w-12 h-12 border border-[#1a2540] flex items-center justify-center flex-shrink-0">
            <svg className="w-6 h-6 text-[#00e5ff]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
            </svg>
          </div>
          <div className="flex-1">
            <div className="font-display text-sm font-bold text-[#e2e8f0] mb-1">
              150+ Algorithmic Problems Solved
            </div>
            <div className="font-body text-sm text-[#718096]">
              Consistent practice on LeetCode and HackerRank — covering arrays, trees, graphs, dynamic programming, and system design fundamentals.
            </div>
          </div>
          <div className="flex-shrink-0">
            <div className="font-display text-3xl font-bold text-[#00e5ff]">
              150+
            </div>
            <div className="font-mono text-[10px] text-[#4a5568] uppercase tracking-wider">
              Problems
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
