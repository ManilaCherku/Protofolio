import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Manila Cherku — Full Stack Engineer",
  description:
    "Full Stack Engineer specializing in MERN stack development and machine learning. Building scalable applications that solve real problems.",
  keywords: [
    "Manila Cherku",
    "Full Stack Developer",
    "MERN Stack",
    "React",
    "Node.js",
    "Software Engineer",
    "Hyderabad",
  ],
  authors: [{ name: "Manila Cherku" }],
  openGraph: {
    title: "Manila Cherku — Full Stack Engineer",
    description:
      "Full Stack Engineer specializing in MERN stack development and machine learning.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="noise">{children}</body>
    </html>
  );
}
