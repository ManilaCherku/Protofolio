# manila-cherku-portfolio

Personal portfolio website for Manila Cherku — Full Stack Engineer & MERN developer.

Built with Next.js 14 (App Router), Tailwind CSS, and TypeScript. Features a dark editorial-geometric aesthetic with animated particle canvas, smooth scroll interactions, and a fully responsive layout optimized for recruiter impact.

## Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Styling**: Tailwind CSS
- **Language**: TypeScript
- **Fonts**: Syne (display), JetBrains Mono, DM Sans

## Sections

- **Hero** — Animated particle network, stat cards, strong CTA
- **About** — Bio, education timeline, certifications
- **Projects** — Featured MERN and ML projects with metrics
- **Skills** — Visual skill bars grouped by category + tag cloud
- **Contact** — Links with copy-to-clipboard email

## Local Setup

```bash
# 1. Clone the repo
git clone https://github.com/ManilaCherku/manila-cherku-portfolio.git
cd manila-cherku-portfolio

# 2. Install dependencies
npm install

# 3. Start the development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Build for Production

```bash
npm run build
npm run start
```

No environment variables required. The project runs out of the box.

## Project Structure

```
src/
├── app/
│   ├── globals.css       # Global styles, fonts, animations
│   ├── layout.tsx        # Root layout with metadata
│   └── page.tsx          # Main page assembling all sections
└── components/
    ├── Navbar.tsx         # Sticky nav with mobile menu
    ├── Hero.tsx           # Animated canvas hero
    ├── About.tsx          # Bio + education timeline
    ├── Projects.tsx       # Featured project cards
    ├── Skills.tsx         # Skill bars + tags
    └── Contact.tsx        # Contact links + footer
```
